Error 920 (SQL Connection Error)

<br><br>This is the 920 error file. The Header file is 9XX