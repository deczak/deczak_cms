<div class="content-outer content-error">
	<div class="content">

		<div>
			<span class="error-code"><?= $pageRequest -> responseCode; ?></span>
		</div>

		<div>
			<span class="error-name"><?= $pageRequest -> page_name; ?></span>
		</div>

	</div>
</div>
