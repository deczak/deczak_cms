<?php /* insert here stuff that comes inside the head-tag */ ?>

<link href="<?php echo CMS_SERVER_URL . DIR_TEMPLATES; ?>default/css/default.css" rel="stylesheet" title="default" media="screen">