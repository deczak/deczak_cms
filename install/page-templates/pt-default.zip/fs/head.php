
<link href="<?php echo CMS_SERVER_URL . DIR_TEMPLATES; ?>default/css/default.css" rel="stylesheet" title="default" media="screen">

<?php if(!CMS_BACKEND) { ?>
<script src="<?php echo CMS_SERVER_URL; ?>js/cms-xhr.php"></script>
<script src="<?php echo CMS_SERVER_URL; ?>js/cms-toolkit.php"></script>
<?php } ?>

<?php /* insert here stuff that comes inside the head-tag */ ?>
