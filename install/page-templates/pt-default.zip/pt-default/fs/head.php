<?php /* insert here stuff that comes inside the head-tag */ ?>

<link href="<?php echo CMS_SERVER_URL; ?>css/default.css" rel="stylesheet" title="default" media="screen">