
<div class="content inner-wrapper">

	<?php	
	$messages -> printMessages();
	$imperator -> view(); 
	?>

</div>
